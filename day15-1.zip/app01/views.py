from django.shortcuts import render,redirect
from app01 import models
# Create your views here.
def index(request):
    name = request.GET.get('name')
    if name and models.User.objects.filter(username=name):
        return render(request,'index.html',{'name':name})
    return render(request,'index.html')

def login(request):
    if request.method == 'POST':
        user=request.POST.get('user')
        passwd=request.POST.get('password')
        if models.User.objects.filter(username=user,password=passwd):
            return redirect('/index/?name='+user)
        elif user=='' or passwd=='':
            return render(request,'login.html',{'error':'用户名或密码不能为空'})
        return render(request,'login.html',{'error':'用户名或密码错误'})
    return render(request,'login.html')

def register(request):
    if request.method == 'POST':
        user = request.POST.get('user')
        passwd = request.POST.get('password')
        if models.User.objects.filter(username=user):
            return  render(request,'register.html',{'error':'用户名已存在'})
        elif not user:
            return render(request, 'register.html', {'error': '用户名不能为空'})
        models.User.objects.create(username=user,password=passwd)
        return redirect('/login/')

    return render(request,'register.html')

def publisher_list(request):
    all_publishers = models.Publisher.objects.all()
    return render(request, 'publisher_list.html', {'all_publishers': all_publishers})


def publisher_add(request):
    if request.method == 'POST':
        pub_name = request.POST.get('pub_name')
        if not pub_name:
            return render(request, 'publisher_add.html', {'error': '名称不能为空'})
        ret = models.Publisher.objects.create(name=pub_name)
        print(ret, type(ret))
        return redirect('/publisher_list/')
    return render(request, 'publisher_add.html')


def publisher_del(request):
    pk = request.GET.get('pk')
    # models.Publisher.objects.get(pk=pk).delete()
    models.Publisher.objects.filter(pk=pk).delete()
    return redirect('/publisher_list/')


def publisher_edit(request):
    pk = request.GET.get('pk')
    obj = models.Publisher.objects.get(pk=pk)
    if request.method == 'POST':
        pub_name = request.POST.get('pub_name')
        obj.name = pub_name
        obj.save()
        return redirect('/publisher_list/')
    return render(request, 'publisher_edit.html', {'obj': obj})